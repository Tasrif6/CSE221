#task-3:
f = open('input3.txt', 'r')
f1 = open('output3.txt', 'w')
data = f.readline().split()
vertices = int(data[0])
edge = int(data[1])
# print(vertices, edge)
graph={i: [] for i in range(0,vertices+1)}
# print(graph)
list1 = []
list2 = []
for j in range(edge):
    x = f.readline().split()
    # print(x)
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
    graph[val2].append(val1)
# print(graph)


def DFS(graph, start):
    stk = []
    stk.append(start)
    visited = []
    while stk:
        vertex = stk.pop(-1)
        if vertex not in visited:
            visited.append(vertex)
            for j in graph[vertex]:
                stk.append(j)
    f1.write(str(visited))
    return visited

h1=DFS(graph,1)
f1.close()
f.close()