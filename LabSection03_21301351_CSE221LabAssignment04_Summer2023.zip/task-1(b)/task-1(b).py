#task-1(B):
f=open('input1(b).txt','r')
f1=open('output1(b)','w')
data=f.readline().split()
vertices=int(data[0])
edge=int(data[1])
new_list=[]
for i in range(vertices+1):
    list2 = []
    new_list.append(list2)

for k in range(edge):
    x=f.readline().split()
    # print(x)
    val1=int(x[0])
    val2=int(x[1])
    val3=int(x[2])
    tup=(val2,val3)

    new_list[val1].append(tup)
f1.write(str(new_list))


# f1.write(str(new_list))
f1.close()
f.close()

