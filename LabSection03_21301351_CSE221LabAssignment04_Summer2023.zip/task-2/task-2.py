f = open('input2.txt', 'r')
f1 = open('output2.txt', 'w')
data = f.readline().split()
vertices = int(data[0])
edge = int(data[1])
print(vertices, edge)
graph={i: [] for i in range(0,vertices+1)}
print(graph)
list1 = []
list2 = []
for j in range(edge):
    x = f.readline().split()
    print(x)
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
    graph[val2].append(val1)
print(graph)

def BFS(graph, start):
    que = []
    que.append(start)
    visited = []
    visited.append(start)
    while len(que) != 0:
        vertex = que.pop(0)
        for j in graph[vertex]:
            if j not in visited:
                que.append(j)
                visited.append(j)
    f1.write(str(visited))
    return visited

h1 = BFS(graph, 1)
f.close()
f1.close()