#task-4:
#using DFS we at first make the tree or graph and then we search whether there are any cycle or not.
f = open('input4.txt', 'r')
f1 = open('output4.txt', 'w')
data = f.readline().split()
vertices = int(data[0])
edge = int(data[1])
print(vertices, edge)
graph={i: [] for i in range(0,vertices+1)}
print(graph)
list1 = []
list2 = []
for j in range(edge):
    x = f.readline().split()
    print(x)
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
    # graph[val2].append(val1)
print(graph)

def DFS(graph, start):
    stk = []
    stk.append(start)
    visited = []
    count=0
    while len(stk)!=0:
        popped_val = stk[-1]
        if popped_val not in visited:
            visited.append(popped_val)
        else:
            count+=1
        stk.pop(-1)
        for j in graph[popped_val]:
            if j not in visited:
                stk.append(j)

    print('count:', count)
    # return visited
    return count

h1 = DFS(graph, 1)
if h1 !=0:
    f1.write('Yes')
else:
    f1.write('No')
f.close()
f1.close()
