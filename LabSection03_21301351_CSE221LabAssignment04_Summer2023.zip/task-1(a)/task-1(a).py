#task-1(A):
f=open('input1(a).txt','r')
f1=open('output1(b).txt','w')
data=f.readline().split()
vertices=int(data[0])
edge=int(data[1])
# inp1=list(input())
# print(inp)
graph=[0]*(vertices+1)*(vertices+1)
list1=[]
for i in range(vertices+1):
    list2 = []
    for j in range(vertices+1):
        list2.append(0)
    list1.append(list2)
#     print(list2)
# print(list1)
for k in range(edge):
    x=f.readline().split()
    # print(list1)
    val1=int(x[0])
    val2=int(x[1])
    val3=int(x[2])
    # print(type(val1))
    list1[val1][val2]=val3

f1.write(str(list1))
f1.close()
f.close()