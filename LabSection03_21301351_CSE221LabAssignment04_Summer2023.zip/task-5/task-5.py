#task-5:
f = open('input5.txt', 'r')
f1 = open('output5.txt', 'w')
data = f.readline().split()
vertices = int(data[0])
edge = int(data[1])
city=int(data[2])
print(vertices, edge,city)
graph={i: [] for i in range(0,vertices+1)}
print(graph)
list1 = []
list2 = []
for j in range(edge):
    x = f.readline().split()
    print(x)
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
    graph[val2].append(val1)
print(graph)

parent_list=[0]*(vertices+1)

def BFS(graph, start):
    que = []
    que.append(start)
    visited = []
    visited.append(start)
    while len(que) != 0:
        vertex = que.pop(0)
        # parent_list[vertices]=city
        # print(parent_list)
        for key in graph[vertex]:
            if key not in visited:
                que.append(key)
                visited.append(key)
                parent_list[key]=vertex
        
        print(parent_list)
    print(visited)
    return visited
    # for k in range(edge):
h1 = BFS(graph, 1)
var=city
path=[]
while var!=0:
    path.append(var)
    var=parent_list[var]

f1.write('Time: '), f1.write(str(len(path)-1))
f1.write(str(path[-1: :-1]))
# print(var)
f1.close()
f.close()