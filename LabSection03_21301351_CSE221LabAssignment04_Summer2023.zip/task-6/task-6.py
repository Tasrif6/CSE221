#task-6:
f=open('input6.txt','r')
f1=open('output6.txt','w')
data=f.readline().split()
val1=int(data[0])
val2=int(data[1])
print(val1,val2)
list1=[]
for i in range(val1):
    # list2=[]
    x=f.readline().strip()
        # x=f.readline().split()
    list1.append(x)
        
print(list1)
count=0
list2=[]
# list1=tuple(list1)
for j in range(len(list1)):
#     for k in range(len(list1)):
#         list2.append(list1[j])
    list2=list1[j]
    for k in range(len(list2)):
        z=list(list2[k])
    # print(z)
 
        if list1[j][k]=='.':
            continue
        if list1[j][k]=='D':
            count+=1
        if list1[j][k]=='#':
            pass
f1.write(str(count))
f1.close()
f.close()

            