#task-1:
print('This is Tasrif Coding>>')
f = open("input1.txt", "r")
f1 = open("output1.txt", "w")
data = f.readline().split()
print(data)
empty = ''
dict1 = {}
# count = 1
roads=[]
for i in range(0,int(data[1])):
    x=f.readline().strip().split()
    roads.append(x)
print(roads)
sorted_list = roads.sort(key=lambda x:int(x[2]))
print(roads)

def union(dict1, u,v,w,list1):
    empty = 0
    # t1, tem_p2 = m1, m2
    p1 = find(dict1, u)
    p2 = find(dict1, v)
    if p1 == p2:
        pass
    else:
        list1.append([u,v,w])
        if dict1[p1] < dict1[p2]:
            dict1[p1] = dict1[p1] + dict1[p2]
            dict1[p2] = p1
        else:
            dict1[p2] = dict1[p1] + dict1[p2]
            dict1[p1] = p2

def find(dict1, city):
    if dict1[city] < 0:
        return city
    else:
        temp = find(dict1, dict1[city])
        dict1[city] = temp
        return temp
for i in range(1, int(data[0]) + 1):
    dict1[i] = -1
list1=[]
small_path = 0
for u,v,w in roads:
    
    union(dict1, int(u), int(v), int(w), list1)
for i in list1:
    small_path += i[2]

f1.write(str(small_path))

f.close()
f1.close()
