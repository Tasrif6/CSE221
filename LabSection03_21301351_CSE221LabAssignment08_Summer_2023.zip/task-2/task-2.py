#task-2:
print('This is Tasrif coding>>')
f=open('input2.txt','r')
f1=open('output2.txt','w')
data=int(f.readline())
dict={}
# print(data)
def num_of_stairs(data,dict):
    if data in dict:
        return dict[data]

    if data==0 or data==1:
        return 1
    elif data==2:
        return 2
    dict[data]=num_of_stairs(data-1,dict)+num_of_stairs(data-2,dict)
    return dict[data]
h1=num_of_stairs(data,dict)
f1.write(str(h1))

f.close()
f1.close()