#task-3
print('This is Tasrif Coding>>')
f=open('input3.txt','r')
f1=open('output3.txt','w')
data= f.readline().strip().split()
print(data)
num_coins=int(data[0])
target=int(data[1])
coins=list(map(int, f.readline().strip().split()))
print(coins)
def coin_change(coins, target):
    list1 = [target+1] * (target + 1)
    list1[0] = 0
    for i in range(1, target + 1):
        for j in coins:
            if j <= i:
                list1[i] = min(list1[i], 1 + list1[i - j])
    # print(list1)
    return -1 if list1[target] > target else list1[target]
result = coin_change(coins, target)

f1.write(str(result))
f.close()
f1.close()

