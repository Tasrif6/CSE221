#task-1:
f=open('input1(O(n2)).txt','r')
f1=open('output1(O(n2)).txt','w')
x=f.readlines()
# print(x)        #['4 10\n', '3 7 1 5']
data1=x[0].split()
# print(data1)        #['4', '10']
num=int(data1[0])
print('Num: ',num)
sum=int(data1[1])
print('Sum: ',sum)
data2=x[1]
data2=x[1].split()
print('data2:',data2)
flag=False
for i in range(0,num-1):
    for j in range(i+1,num):
        if int(data2[i])+int(data2[j])==sum:
            flag=True
            f1.write(str(i+1))
            f1.write(' ')
            f1.write(str(j+1))
    if flag:
        break
if not flag:
    f1.write('impossible')

f1.close()

