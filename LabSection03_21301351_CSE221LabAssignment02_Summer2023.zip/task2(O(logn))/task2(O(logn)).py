#task-2(O(logn)):
f=open('input2logn.txt','r')
f1=open('output2logn.txt','w')
data = f.readlines()

x = data[0].strip()
y = data[1].strip()

sorted_list1 = x.split()
sorted_list2 = y.split()

length = len(sorted_list1) + len(sorted_list2)
result = [None] * length
l = 0
k = 0

for i in range(length):
    if l >= len(sorted_list1):
        result[i] = int(sorted_list2[k])
        k += 1
    elif k >= len(sorted_list2):
        result[i] = int(sorted_list1[l])
        l += 1
    elif int(sorted_list1[l]) > int(sorted_list2[k]):
        result[i] = int(sorted_list2[k])
        k += 1
    else:
        result[i] = int(sorted_list1[l])
        l += 1

result=str(result)
arr=result.strip('[]')
arr.replace(",","")
f1.write(arr)
f1.close()