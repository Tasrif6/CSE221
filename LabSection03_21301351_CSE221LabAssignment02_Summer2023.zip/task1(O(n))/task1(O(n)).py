f=open('input1(O(n)).txt','r')
f1=open('output1(O(n)).txt','w')
x=f.readlines()
data1=x[0].split()
num=int(data1[0])
print(num)
sum=int(data1[1])
print(sum)
data2=x[1].split()
print(data2)
flag=False
i=0
k=num-1
new_list=[]
for j in range(num):
    current_num=int(data2[i])+int(data2[k])
    if current_num==sum:
        f1.write(i,k)
        i+=1
        flag=True
    if flag:
        break
    elif current_num>sum:
        k-=1
    else:
        i+=1
if not flag:
    f1.write('Impossible')

