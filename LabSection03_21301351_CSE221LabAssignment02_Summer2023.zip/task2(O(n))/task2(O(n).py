f=open('input2.txt','r')
f1=open('output2.txt','w')
x=f.readlines()
m=x[1].split()
n=x[3].split()
data1=x[0]
data2=x[2]
print(m)
print(n)
new_list=[]
l=0
k=0
num=int(data1)+int(data2)
for j in range(num-1):
    if int(m[l])<int(n[k]):
        new_list.append(m[l])
        l+=1
    elif int(m[l])>int(n[k]):
        new_list.append(n[k])
        k+=1
    else:
        new_list.append(n[k])
print(new_list)
f1.write(str(new_list))
f1.close()