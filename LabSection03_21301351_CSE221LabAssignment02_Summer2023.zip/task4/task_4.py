#task-4:
f=open('input4.txt','r')
f1=open('output4.txt','w')

x=f.readlines()
arr=x[0].split()
print(arr)
def max_val(arr):
    maxValue = arr[0]
    for i in range(1, len(arr)):
        if maxValue < arr[i]:
            maxValue = arr[i]
    return maxValue

def merge(arr, l, m, r):
    n1 = m - l + 1
    n2 = r - m

    L = [0] * (n1)
    R = [0] * (n2)

    for i in range(0, n1):
        L[i] = arr[l + i]

    for j in range(0, n2):
        R[j] = arr[m + 1 + j]

    i = 0
    j = 0
    k = l

    while i < n1 and j < n2:
        if L[i] <= R[j]:
            arr[k] = L[i]
            i += 1
        else:
            arr[k] = R[j]
            j += 1
        k += 1

    while i < n1:
        arr[k] = L[i]
        i += 1
        k += 1

    while j < n2:
        arr[k] = R[j]
        j += 1
        k += 1

def mergeSort(arr, l, r):
    if l < r-1:
        m = (l+r) // 2

        mergeSort(arr, l, m)
        mergeSort(arr, m+1, r)
        merge(arr, l, m, r)

arr = [5, 15, 2, 3, 10, 11, 9]
h1 = max_val(arr)
mergeSort(arr, 0, len(arr)-1)
f1.write(str(arr))
f1.close()

# Here mergesort has a time complexity of O(nlogn) for its divide and conquer approach. Also the max val has O(n).
# And the merge function works in O(nlogn) case. However, in this code we can clearly see that the max value and mergesort function has no relation with them.
#Therefore the Time complexity will be O(nlogn).
