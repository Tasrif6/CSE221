f=open('input3.txt','r')
f1=open('output3.txt','w')
data=f.readline().strip().split()

vertices=int(data[0])
edge=int(data[1])

graph={} 
graph2={} 
graph={i: [] for i in range(0,vertices+1)}
graph2={i: [] for i in range(0,vertices+1)}
# print(graph)
list1 = []
list2 = []
for j in range(edge):
    x = f.readline().split()
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
    graph2[val2].append(val1)
print('graph1:',graph)
print('graph2:',graph2)

for key,value in graph2.items():
    list1.append(value)
top=list1


def DFS(graph,n,visited,stk):
    visited[n]=1
    for i in graph[n]:
        if visited[i]!=1:
            DFS(graph,i,visited,stk)
    stk.append(n)

def scc(graph,graph2):
    visited=[0]*len(graph)
    stack=[]
    for j in range(1,len(graph)):
        if visited[j]!=1:
            DFS(graph,j,visited,stack)

    visited=[0]*len(graph)
    scc=[]
    while len(stack)!=0:
        val=stack.pop()

        if visited[val]==0:
            stack2=[]  #using a second stack to get the connected componenets
            DFS(top,val,visited,stack2)  #doing dfs on reverse list
            scc.append(stack2)
    return scc
x=scc(graph,top)
x.sort()
final_list=[]
for i in x:
  i.sort()
  final_list.append(i)
# print(final_list)
f1.write(str(final_list))
f.close()
f1.close()