#task-1(a):
print('This is Tasrif Coding.>>')

f=open('input1(a).txt','r')
f1=open('output1(a).txt','w')
data=f.readline().strip().split()
print(data)
vertices=int(data[0])
edge=int(data[1])
graph={i:[] for i in range(vertices+1)}
print(graph)
for j in range(edge):
    x=f.readline().split()
    val1=int(x[0])
    val2=int(x[1])
    graph[val1].append(val2)
print(graph)
list1=[0]*len(graph)
for key,value in graph.items():
    # indegree=0
    if value!=[]:
        for l in value:
            # indegree+=1
            list1[l]+=1

    # graph[val2].append(val1)
# print(graph)
print(list1)

def BFS(graph, indegree, start):
    que = []
    # visited = []
    # visited.append(start)
    new_list=[]
    for m in range(1,len(list1)):
        if list1[m]==0:
            que.append(m)
    print('que:', que)
    while len(que) != 0:
        vertex = que.pop()
        # parent_list[vertices]=city
        # print(parent_list)
        print(new_list)
        new_list.append(vertex)
        for key in graph[vertex]:
            # if key not in visited:
            list1[key]-=1
            if list1[key]==0:
                que.append(key)
                # visited.append(key)
    if len(new_list)!=vertices:
        print('Impossible')
    f1.write(str(new_list))
    return new_list

#driver code:
h1=BFS(graph,vertices, 1)
f.close()
f1.close()