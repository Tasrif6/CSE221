f=open('input3.txt','r')
f1=open('output3.txt','w')

x=int(f.readline().strip())
data=f.readlines()
marks=data[1].split(' ')
id=data[0].split(' ')
print(id)
print(marks)
print(x)
for i in range(x): 
    for j in range(x-i-1):
        if marks[j] < marks[j+1]:
            id[j], id[j+1] = id[j+1], id[j]
            marks[j], marks[j+1] = marks[j+1], marks[j]
        elif marks[j]==marks[j+1]:
            if id[j]>id[j+1]:
                id[j],id[j+1]=id[j+1],id[j]
            else:
                pass
print(f'Id: {id} Marks: {marks}')
for k in range(x):
    f1.write(f"ID: {int(id[k])} Marks: {int(marks[k])}\n")

f.close()
f1.close()

#Here declared the second line as id and the first line as marks by index data[0] & data[1]. after that in the loop made a bubble sort and made a swaping and sorting in marks as descending order.
#Then again at elif for the id to be in the ascending order if the marks are same same then, id value swapping and be in ascending order in the 19 no line. 
#Finally another for loop to make the output come serially.