f=open('input2.txt','r')
f1=open('output2.txt','w')
x=f.readlines()
arr=x[1].split()
def bubbleSort(arr):
    count=0
    for i in range(len(arr)-1):
        for j in range(len(arr)-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]
                count+=1
    if count==0:
        f1.write(f'No change {str(arr)}')
    else:
        f1.write(str(arr))
    
bubbleSort(arr)
f.close()
f1.close()

#here at first declared a count=0. then in the for loop if the condition passes then I will increment the count by 1 othewise no change will be made.
