#Task-04

f = open('input4.txt','r')
f1=open('output4.txt','w')
x = int(f.readline())  #13
data = [str(f.readline().strip()) for i in range(x)]
#print(data)

def compareTime(time1, time2):
    t1 = float(time1.split(":")[0]) + (float(time1.split(":")[1]) / 60.00)
    t2 = float(time2.split(":")[0]) + (float(time2.split(":")[1]) / 60.00)
    #print(t1)
    #print(t2)
    if t1 > t2:
        return True
    else:
        return False

for i in range(x-1):
    for j in range(x - i - 1):
        if data[j].split(' ')[0] > data[j+1].split(' ')[0]:
            #swap(data, j, j+1)
            data[j],data[j+1]=data[j+1],data[j]
        elif data[j].split(' ')[0] == data[j+1].split(' ')[0]:
            if compareTime(data[j].split(' ')[-1], data[j+1].split(' ')[-1]) != True:
                #swap(data, j, j+1)
                data[j],data[j+1]=data[j+1],data[j]
#print(f'{data}\n')
for k in range(len(data)):
    f1.write(f'{data[k]}\n')
f.close()
f1.close()

#Here at first did that alphabetical ascending order. Implemented directly by index rather than using ascii values here. 
#At the first 6 no line the whole text was coming into a list as a single index. then in the loop defined that those index's value by split() function then -1 index meaning our last index like C/D/E check.
#after completing those alphabetical check and sort made a function to compare the times. As the values are in a clock system. So made divided them by 60.
#which gives us a value and comparing those index[0] and index [1] times of ABC like we get the sorting ordered format output in time as well.