#task-1(b)
f=open('input1(b).txt','r')
f1=open('output1(b).txt','w')

# x=f.readlines()
# print(x)    #5
x=int(f.readline())
for i in range(x):
    y=f.readline().split(' ')
    # print(y)
    if y[2]=='+':
        f1.write(f'The result of {int(y[1])} {y[2]} {int(y[3])} is {int(y[1])+int(y[3])}\n')
    elif y[2]=='-':
        f1.write(f'The result of {int(y[1])} {y[2]} {int(y[3])} is {int(y[1])-int(y[3])}\n')
    elif y[2]=='*':
        f1.write(f'The result of {int(y[1])} {y[2]} {int(y[3])} is {int(y[1])*int(y[3])}\n')
    else:
        f1.write(f'The result of {int(y[1])} {y[2]} {int(y[3])} is {int(y[1])/int(y[3])}\n')

f.close()
f1.close()


#Here also in for loop I declared by index that if the opertor sign is this, then this operation will take place followed by index's. operators:(+,-,*,/)
