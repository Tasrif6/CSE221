#Task-1(a):
f=open('input1(a).txt','r')
f1=open('output1(a).txt','w')

x=int(f.readline())
print(x)
for i in range(x):
    current_number=int(f.readline())
    if current_number%2==0:
        f1.write(f'{current_number} is an Even number.\n')
    else:
        f1.write(f'{current_number} is an Odd number.\n')

f.close()
f1.close()

#Explanation:
#At first input and output text file created then opened them after that in readline() function we got the first value for our loop range.
#Then in if else condition I checked if it is % by 2 then even else odd.