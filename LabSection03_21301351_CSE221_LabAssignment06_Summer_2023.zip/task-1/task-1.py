#task-1:
print('This is Tasrif Coding>>')
import math
# from queue import PriorityQueue
import heapq
f=open('input1.txt','r')
f1=open('output1.txt','w')
data=f.readline().strip().split()
vertices=int(data[0])
edge=int(data[1])
print(vertices,edge)
graph={}
for i in range(vertices+1):
    graph[i]=[]
for j in range(edge):
    x=f.readline().strip().split()
    y=int(x[1]),int(x[2])
    graph[int(x[0])].append(y)
print(graph)
s=int(f.readline())    #Calling source value
print(s)
def dijkstra_function(graph,source,vertices):
    l=len(graph)
    # print(l)
    distances=[math.inf for i in range(vertices+1)]
    # print(distances)
    distances[source]=0
    print(distances)
    # visited=[]
    # queue=PriorityQueue()
    visited=[False for i in range(l)]
    queue=[(0,source)]
    # queue.append(distances)
    print(queue)
    while queue:
        dist,vertex=heapq.heappop(queue)
        print(vertex)
        if visited[vertex]:
            continue
        visited[vertex]=True
        for neigh,neigh_dist in graph[vertex]:
            length=dist+neigh_dist
            if length < distances[neigh]:
                distances[neigh] = length
                heapq.heappush(queue, (length, neigh))
    for j in range(1,len(distances)):
        if distances[j]==math.inf:
            distances[j]=-1
    return distances[1:]
    # new_list=[]
    # for i in distances:
    #     if i!=math.inf:
    #         new_list.append(i)
    # return new_list
    # # return distances


#driver code:
h1=dijkstra_function(graph,s,vertices)
f1.write(str(h1))

f.close()
f1.close()