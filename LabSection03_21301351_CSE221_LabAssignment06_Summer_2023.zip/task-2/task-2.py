#task-2:
print('This is Tasrif Coding>>')
import math
# from queue import PriorityQueue
import heapq
f=open('input2.txt','r')
f1=open('output2.txt','w')
data=f.readline().strip().split()
vertices=int(data[0])
edge=int(data[1])
print(vertices,edge)
graph={}
for i in range(vertices+1):
    graph[i]=[]
for j in range(edge):
    x=f.readline().strip().split()
    y=int(x[1]),int(x[2])
    graph[int(x[0])].append(y)
print(graph)
s=f.readline().strip().split()   #Calling source value
alice_s=int(s[0])
bob_s=int(s[1])
print(alice_s,bob_s)


def dijkstra_function(graph,source,vertices):
    l=len(graph)
    distances=[math.inf for i in range(vertices+1)]
    # print(distances)
    distances[source]=0
    print(distances)
    # visited=[]
    # queue=PriorityQueue()
    visited=[False for i in range(l)]
    queue=[(0,source)]
    # queue.append(distances)
    print(queue)
    while queue:
        dist,vertex=heapq.heappop(queue)
        print(dist,vertex)
        if dist > distances[vertex]:
            continue
        visited[vertex]=True
        for weight,neigh_dist in graph[vertex]:
            length=dist+neigh_dist
            if length < distances[weight]:
                distances[weight] = length
                heapq.heappush(queue, (length, weight))
    return distances



#driver code:
h1=dijkstra_function(graph,alice_s,vertices)
h2=dijkstra_function(graph,bob_s,vertices)
print(h1)
print(h2)
h3=max(h1,h2)
# print(h3)
invalid=-1
list1=[]
list2=[]
for i in range(1,vertices+1):
    if h1[i]==math.inf or h2[i]==math.inf:
        continue
    if float(h3[i]) < math.inf:
        invalid=i
        # print(invalid)
        x=h3[i],invalid
        list1.append(x)
f1.write(str(min(list1[0],list1[1])))
if invalid==-1:
    f1.write('Impossible')
# else:
#     print('Time',h3[i])
#     print('Node:',invalid)
f1.close()
f.close()
