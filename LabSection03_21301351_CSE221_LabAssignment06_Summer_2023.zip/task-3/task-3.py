#task-3:
print('This is Tasrif Coding>>')
import math
# from queue import PriorityQueue
import heapq
f=open('input3.txt','r')
f1=open('output3.txt','w')
data=f.readline().strip().split()
vertices=int(data[0])
edge=int(data[1])
print(vertices,edge)
graph={}
for i in range(vertices+1):
    graph[i]=[]
for j in range(edge):
    x=f.readline().strip().split()
    y=int(x[1]),int(x[2])
    graph[int(x[0])].append(y)
print(graph)
# s=f.readline().strip().split()
# print(s)

def dijkstra_function(graph,source,vertices):
    l=len(graph)
    distances=[math.inf for i in range(vertices+1)]
    # print(distances)
    distances[source]=0
    print('d:',distances)
    # visited=[]
    # queue=PriorityQueue()
    visited=[False for i in range(l)]
    queue=[(0,source)]
    # queue.append(distances)
    print(queue)
    while queue:
        dng,vertex=heapq.heappop(queue)
        # print(dng,vertex)
        if dng > distances[vertex]:
            continue
        visited[vertex]=True
        for weight,neigh_dist in graph[vertex]:
            length=max(dng,neigh_dist)
            print('l',length)
            if length < distances[weight]:
                distances[weight] = length
                heapq.heappush(queue, (length, weight))
    return distances[vertices]



#driver code:
h1=dijkstra_function(graph,1,vertices)
f1.write(str(h1))

f1.close()
f.close()