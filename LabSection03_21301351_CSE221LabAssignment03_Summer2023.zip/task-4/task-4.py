f = open('input4.txt', 'r')
f1 = open('output4.txt', 'w')
data = f.readlines()
x = int(data[0][0])
arr = data[1].split()
print(arr)
y = int(data[2][0])

total_queries = []
for i in range(y-1):
    query = int(data[3+i].strip())  # Convert queries to integers
    total_queries.append(query)

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1

    for j in range(low, high):
        if arr[j] <= pivot:
            i += 1
            arr[i], arr[j] = arr[j], arr[i]

    arr[i+1], arr[high] = arr[high], arr[i+1]
    return i + 1

def right_shift(array):
    temp = array[-1]
    for i in range(len(array) - 1, 0, -1):
        array[i] = array[i - 1]
    array[0] = temp
    return array

result = []
for query in total_queries:
    for i in range(x):
        h1 = partition(arr, 0, x - 1)
        if h1 == query:
            result.append(arr[-1])
            break
        else:
            arr = right_shift(arr)

for k in result:
    f1.write(str(k) + '\n')

f1.close()
f.close()






