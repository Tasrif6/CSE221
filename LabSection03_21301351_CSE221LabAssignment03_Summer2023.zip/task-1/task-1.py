#task-1:
f = open('input1.txt', 'r')
f1 = open('output1.txt', 'w')
data=f.readlines()
p = int(data[0])
q = data[1].split(' ')
lst = []

for i in range(len(q)):
    lst.append(int(q[i]))

count = 0

def merge_sort(arr):
    global count

    if len(arr) > 1:
        mid = len(arr) // 2
        left_half = arr[:mid]
        right_half = arr[mid:]
        merge_sort(left_half)
        merge_sort(right_half)
        
        i = 0
        j = 0
        k = 0

        while i < len(left_half) and j < len(right_half):
            if left_half[i] <= right_half[j]:
                arr[k] = left_half[i]
                i += 1
            else:
                arr[k] = right_half[j]
                j += 1
                count += len(left_half) - i
            k += 1

        while i < len(left_half):
            arr[k] = left_half[i]
            i += 1
            k += 1

        while j < len(right_half):
            arr[k] = right_half[j]
            j += 1
            k += 1

    return count

f1.write(str(merge_sort(lst)))
f.close()
f1.close()