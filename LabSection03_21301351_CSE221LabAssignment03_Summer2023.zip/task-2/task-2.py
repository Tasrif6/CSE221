#task-2:
f=open('input2.txt','r')
f1=open('output2.txt','w')
data=f.readlines()
length=int(data[0])
list1=data[1].split()
new_list=[]
for i in range(len(list1)):
    new_list.append(int(list1[i]))
print(new_list)
print(length)
def cross_max(list1):
    maximum_leftnumber= max(list1[:(len(list1)//2)])#might require multiple lines
    right_array=list1[(len(list1)//2):]
    new_list=[]
    for i in range(len(right_array)):
        new_list.append(abs(right_array[i]))
    maximum_rightnumber= max(new_list)
    return maximum_leftnumber+(maximum_rightnumber**2)

def get_max(list1):
    if len(list1)==1:
        return float('-inf')

    if len(list1)==2:
        x=list1[0]+(list1[1]*list1[1])
        return x

    else:
        count=0
        left_max=get_max(list1[:(len(list1)//2)])
        right_max=get_max(list1[(len(list1)//2):])
        cross_max1=cross_max(list1)
        result= max(left_max,right_max,cross_max1)
        # f1.write(str(result))
        return result
# # list1=[-5,-2,-6,-7,-1,8,2]
h1=get_max(new_list)
f1.write(str(h1))
# cross_max(list1)
f1.close()
f.close()
# print(h1)