#task-3:
f=open('input3.txt','r')
f1=open('output3.txt','w')
data=f.readlines()
x=int(data[0])
arr=data[1].split()

print(x)
print(arr)
def swap(arr, a, b):
    arr[a], arr[b] = arr[b], arr[a]

def partition(arr, low, high):
    pivot = arr[high]
    i = low - 1

    for j in range(low, high):
        if arr[j] < pivot:
            i += 1
            swap(arr, i, j)

    swap(arr, i + 1, high)
    return i + 1

def quickSort(arr, low, high):
    if low < high:
        pi = partition(arr, low, high)
        quickSort(arr, low, pi - 1)
        quickSort(arr, pi + 1, high)

# arr = [9,5,4,6,1,3,2,9]
# N = len(arr)
quickSort(arr, 0, x - 1)
f1.write("Sorted array:")
for i in range(x):
    f1.write(arr[i]) #, end=" ")
    f1.write(' ')

f1.close()
f.close()